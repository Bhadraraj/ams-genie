import React, { useState, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import ChatHistoryItem from './ChatHistoryItem';

interface ChatHistory {
  chatId: string;
  chatSummary: string;
  lastUpdatedTime: string;
  userId: string;
}

interface ChatHistoryListProps {
  onChatSelect: () => void;
}

const ChatHistoryList: React.FC<ChatHistoryListProps> = ({ onChatSelect }) => {
  const { setCurrentChat, currentChat, searchTerm, setChatHistory, shouldRefetch } = useChat();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const userId = "babu.s@sirc.sa";

  const fetchChatHistory = async () => {
    try {
      setLoading(true);
      console.log('Fetching chat history...');
      
      const response = await fetch(`https://api-config.amsgenius.com/api/chat_history/${encodeURIComponent(userId)}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data: ChatHistory[] = await response.json();
      console.log('API Response:', data);
      
      setChatHistory(data);
      setError(null);
    } catch (err) {
      console.error('Error:', err);
      setError('Failed to load History');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChatHistory();
  }, [userId, shouldRefetch, setChatHistory]);

 const handleChatClick = async (chat: ChatHistory) => {
  setCurrentChat(null); 
  
  try {
    const response = await fetch(`https://api-config.amsgenius.com/api/chat/${encodeURIComponent(chat.chatId)}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const fullChatData = await response.json();
    
    if (!fullChatData || fullChatData.length === 0) {
      throw new Error("No chat data found for this ID.");
    }
    
    const chatDetail = fullChatData[0];

    // Create messages from the chat data
    const userMessage = {
      id: chatDetail.id + '-user',
      content: chatDetail.errorDescription, // Use original error description
      sender: 'user',
      timestamp: chatDetail.createdDate,
    };

    const systemSolution = {
      id: chatDetail.id + '-solution',
      content: chatDetail.solution,
      sender: 'system',
      timestamp: chatDetail.createdDate,
    };

    const formattedMessages = [userMessage, systemSolution];

    // CRITICAL FIX: Include the chatSeq from the API response
    setCurrentChat(
      { 
        id: chat.chatId,
        title: chat.chatSummary, 
        lastMessage: chat.chatSummary, 
        timestamp: chat.lastUpdatedTime,
        seq: chatDetail.chatSeq 
      }, 
      formattedMessages
    );
    
    console.log("✅ Chat loaded with sequence:", {
      chatId: chat.chatId,
      chatSeq: chatDetail.chatSeq,
      title: chat.chatSummary
    });
    
    onChatSelect();
  } catch (err) {
    console.error('Error fetching full chat:', err);
  }
};
  const { filteredChatHistory } = useChat();

  // Helper function to sort chats by most recent first
  const sortChatsByMostRecent = (chats: ChatHistory[]) => {
    return chats
      .slice() // Create a copy to avoid mutating original array
      .sort((a, b) => {
        // Convert timestamps to Date objects for comparison
        const dateA = new Date(a.lastUpdatedTime);
        const dateB = new Date(b.lastUpdatedTime);
        
        // Sort in descending order (most recent first)
        return dateB.getTime() - dateA.getTime();
      });
  };

  if (loading) {
    return (
      <div className="p-4 text-center text-gray-400">Loading chat history...</div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-center text-red-400">Error: {error}</div>
    );
  }

  // Get sorted chats (most recent first)
  const sortedChats = sortChatsByMostRecent(filteredChatHistory);

  console.log('🕒 Chat sorting debug:', {
    originalCount: filteredChatHistory.length,
    sortedCount: sortedChats.length,
    firstChat: sortedChats[0]?.chatSummary + ' - ' + sortedChats[0]?.lastUpdatedTime,
    lastChat: sortedChats[sortedChats.length - 1]?.chatSummary + ' - ' + sortedChats[sortedChats.length - 1]?.lastUpdatedTime
  });

  return (
    <div className="divide-y divide-blue-900 cardMain">
      {sortedChats.length > 0 ? (
        sortedChats.map((chat) => (
          <ChatHistoryItem
            key={chat.chatId}
            chat={{ 
              id: chat.chatId, 
              title: chat.chatSummary, 
              timestamp: chat.lastUpdatedTime, 
              lastMessage: '' 
            }}
            isActive={currentChat?.id === chat.chatId}
            onClick={() => handleChatClick(chat)}
          />
        ))
      ) : (
        <div className="p-4 text-center text-gray-400">
          {searchTerm ? `No chats found for "${searchTerm}"` : 'No chat history found'}
        </div>
      )}
    </div>
  );
};

export default ChatHistoryList;